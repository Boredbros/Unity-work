﻿using UnityEngine;

abstract public class Projectile : MonoBehaviour
{
    
}
