﻿using UnityEngine;

abstract public class Weapon : MonoBehaviour 
{
    public abstract void Fire(Transform attackSpawnPoint);
}
